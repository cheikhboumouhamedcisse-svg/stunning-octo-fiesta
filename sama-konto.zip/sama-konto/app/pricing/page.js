import { createServerSupabase } from '@/lib/supabaseServer';
import CheckoutButton from '@/components/CheckoutButton';

export default async function PricingPage() {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();

  return (
    <div className="container" style={{ paddingTop: 40 }}>
      <h1 style={{ textAlign: 'center' }}>Nos formules</h1>
      <p className="muted" style={{ textAlign: 'center' }}>
        Choisissez la formule adaptée à votre entreprise. Le module RH peut être ajouté séparément.
      </p>

      <div className="grid grid-3">
        <div className="card">
          <h2>Simple</h2>
          <h3 style={{ color: 'var(--or-fonce)' }}>5 000 FCFA/mois</h3>
          <p className="muted">Facturation, devis, clients, dépenses.</p>
          {user
            ? <CheckoutButton priceId={process.env.STRIPE_PRICE_SIMPLE} label="Choisir Simple" />
            : <a href="/signup" className="btn btn-or" style={{ width: '100%', textAlign: 'center' }}>Créer un compte</a>}
        </div>
        <div className="card" style={{ border: '2px solid var(--or)' }}>
          <h2>Pro</h2>
          <h3 style={{ color: 'var(--or-fonce)' }}>7 500 FCFA/mois</h3>
          <p className="muted">Tout Simple + rapports avancés.</p>
          {user
            ? <CheckoutButton priceId={process.env.STRIPE_PRICE_PRO} label="Choisir Pro" />
            : <a href="/signup" className="btn btn-or" style={{ width: '100%', textAlign: 'center' }}>Créer un compte</a>}
        </div>
        <div className="card">
          <h2>Pro Max</h2>
          <h3 style={{ color: 'var(--or-fonce)' }}>15 000 FCFA/mois</h3>
          <p className="muted">Tout Pro + module RH inclus.</p>
          {user
            ? <CheckoutButton priceId={process.env.STRIPE_PRICE_PROMAX} label="Choisir Pro Max" />
            : <a href="/signup" className="btn btn-or" style={{ width: '100%', textAlign: 'center' }}>Créer un compte</a>}
        </div>
      </div>

      {user && (
        <div className="card">
          <h3>Add-on RH (si vous n'êtes pas en Pro Max)</h3>
          <div className="grid grid-2">
            <div>
              <p>RH pour Simple — 3 000 FCFA/mois</p>
              <CheckoutButton priceId={process.env.STRIPE_PRICE_RH_SIMPLE} label="Activer RH (Simple)" />
            </div>
            <div>
              <p>RH pour Pro — 2 000 FCFA/mois</p>
              <CheckoutButton priceId={process.env.STRIPE_PRICE_RH_PRO} label="Activer RH (Pro)" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
