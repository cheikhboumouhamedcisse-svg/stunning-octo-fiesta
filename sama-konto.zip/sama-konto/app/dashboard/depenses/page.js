import { createServerSupabase } from '@/lib/supabaseServer';
import { addExpense, deleteExpense } from '@/lib/actions';

export default async function DepensesPage() {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: expenses } = await supabase
    .from('expenses').select('*').eq('user_id', user.id).order('date', { ascending: false });

  return (
    <div>
      <h1>Dépenses</h1>
      <div className="card">
        <h3>Nouvelle dépense</h3>
        <form action={addExpense}>
          <input className="input" name="date" type="date" defaultValue={new Date().toISOString().slice(0, 10)} />
          <select className="input" name="category" required>
            <option value="Loyer">Loyer</option>
            <option value="Fournitures">Fournitures</option>
            <option value="Transport">Transport</option>
            <option value="Salaires">Salaires</option>
            <option value="Autre">Autre</option>
          </select>
          <input className="input" name="description" placeholder="Description (ex: Achat de fournitures)" />
          <input className="input" name="amount" type="number" step="0.01" placeholder="Montant (FCFA)" required />
          <button className="btn btn-or" type="submit">Enregistrer</button>
        </form>
      </div>
      <div className="card">
        <table>
          <thead><tr><th>Date</th><th>Catégorie</th><th>Description</th><th>Montant</th><th></th></tr></thead>
          <tbody>
            {(expenses || []).map(e => (
              <tr key={e.id}>
                <td>{e.date}</td><td>{e.category}</td><td>{e.description}</td>
                <td>{Number(e.amount).toLocaleString('fr-FR')} FCFA</td>
                <td>
                  <form action={deleteExpense.bind(null, e.id)}>
                    <button className="btn btn-outline" type="submit">Supprimer</button>
                  </form>
                </td>
              </tr>
            ))}
            {(!expenses || expenses.length === 0) && <tr><td colSpan={5} className="muted">Aucune dépense pour l'instant.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
