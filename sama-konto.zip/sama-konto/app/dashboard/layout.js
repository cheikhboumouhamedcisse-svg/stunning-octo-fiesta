import { createServerSupabase } from '@/lib/supabaseServer';
import { createAdminSupabase } from '@/lib/supabaseAdmin';
import { PLAN_LABELS } from '@/lib/stripe';
import LogoutButton from '@/components/LogoutButton';
import ManageSubscriptionButton from '@/components/ManageSubscriptionButton';
import Link from 'next/link';

export default async function DashboardLayout({ children }) {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();

  const admin = createAdminSupabase();
  const { data: profile } = await admin
    .from('profiles')
    .select('plan, rh_addon, company_name, subscription_status')
    .eq('id', user.id)
    .single();

  const plan = profile?.plan || 'simple';
  const rhAddon = !!profile?.rh_addon;

  return (
    <div>
      <div className="topbar">
        <div className="container">
          <span className="brand">Sama Konto</span>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <span className="badge badge-or">{PLAN_LABELS[plan] || plan}</span>
            <ManageSubscriptionButton />
            <LogoutButton />
          </div>
        </div>
      </div>
      <div className="container">
        <nav className="nav-dash">
          <Link href="/dashboard">Tableau de bord</Link>
          <Link href="/dashboard/factures">Factures</Link>
          <Link href="/dashboard/devis">Devis</Link>
          <Link href="/dashboard/clients">Clients</Link>
          <Link href="/dashboard/depenses">Dépenses</Link>
          <Link href="/dashboard/rh">RH {!rhAddon && '🔒'}</Link>
          <Link href="/pricing">Abonnement</Link>
        </nav>
        {profile?.subscription_status && profile.subscription_status !== 'active' && plan !== 'simple' && (
          <p className="muted" style={{ color: 'var(--rouge)' }}>
            Statut abonnement : {profile.subscription_status}
          </p>
        )}
        {children}
      </div>
    </div>
  );
}
