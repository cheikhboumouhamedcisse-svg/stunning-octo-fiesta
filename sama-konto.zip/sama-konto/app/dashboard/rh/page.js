import { createServerSupabase } from '@/lib/supabaseServer';
import { addEmployee, markAttendance, requestLeave, setLeaveStatus } from '@/lib/actions';

export default async function RHPage() {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();

  const { data: profile } = await supabase.from('profiles').select('rh_addon').eq('id', user.id).single();

  if (!profile?.rh_addon) {
    return (
      <div>
        <h1>Module RH</h1>
        <div className="card">
          <p>Le module RH (employés, présence, congés) est un add-on payant.</p>
          <a href="/pricing" className="btn btn-or">Activer le module RH</a>
        </div>
      </div>
    );
  }

  const today = new Date().toISOString().slice(0, 10);
  const [{ data: employees }, { data: attendanceToday }, { data: leaves }] = await Promise.all([
    supabase.from('employees').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
    supabase.from('attendance').select('*').eq('user_id', user.id).eq('date', today),
    supabase.from('leaves').select('*, employees(name)').eq('user_id', user.id).order('created_at', { ascending: false }),
  ]);

  const attendanceMap = Object.fromEntries((attendanceToday || []).map(a => [a.employee_id, a.status]));

  return (
    <div>
      <h1>Module RH</h1>

      <div className="card">
        <h3>Ajouter un employé</h3>
        <form action={addEmployee}>
          <input className="input" name="name" placeholder="Nom complet" required />
          <input className="input" name="role" placeholder="Poste" />
          <input className="input" name="salary" type="number" step="0.01" placeholder="Salaire mensuel (FCFA)" />
          <button className="btn btn-or" type="submit">Ajouter</button>
        </form>
      </div>

      <div className="card">
        <h3>Présence du jour ({today})</h3>
        <table>
          <thead><tr><th>Employé</th><th>Poste</th><th>Statut</th><th></th></tr></thead>
          <tbody>
            {(employees || []).map(emp => (
              <tr key={emp.id}>
                <td>{emp.name}</td>
                <td>{emp.role}</td>
                <td>
                  <span className={`badge ${attendanceMap[emp.id] === 'absent' ? 'badge-rouge' : 'badge-vert'}`}>
                    {attendanceMap[emp.id] || 'non pointé'}
                  </span>
                </td>
                <td style={{ display: 'flex', gap: 8 }}>
                  <form action={markAttendance.bind(null, emp.id, 'présent')}>
                    <button className="btn btn-or" type="submit">Présent</button>
                  </form>
                  <form action={markAttendance.bind(null, emp.id, 'absent')}>
                    <button className="btn btn-outline" type="submit">Absent</button>
                  </form>
                </td>
              </tr>
            ))}
            {(!employees || employees.length === 0) && <tr><td colSpan={4} className="muted">Aucun employé pour l'instant.</td></tr>}
          </tbody>
        </table>
      </div>

      <div className="card">
        <h3>Demander un congé</h3>
        <form action={requestLeave}>
          <select className="input" name="employee_id" required>
            <option value="">-- Employé --</option>
            {(employees || []).map(emp => <option key={emp.id} value={emp.id}>{emp.name}</option>)}
          </select>
          <input className="input" name="start_date" type="date" required />
          <input className="input" name="end_date" type="date" required />
          <input className="input" name="type" placeholder="Type (congé payé, maladie...)" defaultValue="congé payé" />
          <button className="btn btn-or" type="submit">Envoyer la demande</button>
        </form>
      </div>

      <div className="card">
        <h3>Congés</h3>
        <table>
          <thead><tr><th>Employé</th><th>Du</th><th>Au</th><th>Type</th><th>Statut</th><th></th></tr></thead>
          <tbody>
            {(leaves || []).map(l => (
              <tr key={l.id}>
                <td>{l.employees?.name}</td><td>{l.start_date}</td><td>{l.end_date}</td><td>{l.type}</td>
                <td>
                  <span className={`badge ${l.status === 'approuvé' ? 'badge-vert' : l.status === 'refusé' ? 'badge-rouge' : 'badge-or'}`}>
                    {l.status}
                  </span>
                </td>
                <td style={{ display: 'flex', gap: 8 }}>
                  {l.status === 'en attente' && (
                    <>
                      <form action={setLeaveStatus.bind(null, l.id, 'approuvé')}>
                        <button className="btn btn-or" type="submit">Approuver</button>
                      </form>
                      <form action={setLeaveStatus.bind(null, l.id, 'refusé')}>
                        <button className="btn btn-outline" type="submit">Refuser</button>
                      </form>
                    </>
                  )}
                </td>
              </tr>
            ))}
            {(!leaves || leaves.length === 0) && <tr><td colSpan={6} className="muted">Aucune demande de congé.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
