import { createServerSupabase } from '@/lib/supabaseServer';
import { addQuote, deleteQuote } from '@/lib/actions';

export default async function DevisPage() {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  const [{ data: quotes }, { data: clients }] = await Promise.all([
    supabase.from('quotes').select('*, clients(name)').eq('user_id', user.id).order('created_at', { ascending: false }),
    supabase.from('clients').select('id, name').eq('user_id', user.id),
  ]);

  return (
    <div>
      <h1>Devis</h1>
      <div className="card">
        <h3>Nouveau devis</h3>
        <form action={addQuote}>
          <input className="input" name="number" placeholder="Numéro (ex: DEV-2026-001)" required />
          <select className="input" name="client_id">
            <option value="">-- Client (optionnel) --</option>
            {(clients || []).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <input className="input" name="description" placeholder="Description" />
          <input className="input" name="total" type="number" step="0.01" placeholder="Montant (FCFA)" required />
          <button className="btn btn-or" type="submit">Créer le devis</button>
        </form>
      </div>
      <div className="card">
        <table>
          <thead><tr><th>N°</th><th>Client</th><th>Montant</th><th>Statut</th><th></th></tr></thead>
          <tbody>
            {(quotes || []).map(q => (
              <tr key={q.id}>
                <td>{q.number}</td>
                <td>{q.clients?.name || '—'}</td>
                <td>{Number(q.total).toLocaleString('fr-FR')} FCFA</td>
                <td><span className="badge badge-or">{q.status}</span></td>
                <td>
                  <form action={deleteQuote.bind(null, q.id)}>
                    <button className="btn btn-outline" type="submit">Supprimer</button>
                  </form>
                </td>
              </tr>
            ))}
            {(!quotes || quotes.length === 0) && <tr><td colSpan={5} className="muted">Aucun devis pour l'instant.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
