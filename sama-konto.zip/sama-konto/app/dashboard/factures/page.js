import { createServerSupabase } from '@/lib/supabaseServer';
import { addInvoice, deleteInvoice, markInvoicePaid } from '@/lib/actions';

const STATUS_LABEL = { draft: 'Brouillon', sent: 'Envoyée', paid: 'Payée', overdue: 'En retard' };
const STATUS_BADGE = { draft: 'badge-or', sent: 'badge-or', paid: 'badge-vert', overdue: 'badge-rouge' };

export default async function FacturesPage() {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  const [{ data: invoices }, { data: clients }] = await Promise.all([
    supabase.from('invoices').select('*, clients(name)').eq('user_id', user.id).order('created_at', { ascending: false }),
    supabase.from('clients').select('id, name').eq('user_id', user.id),
  ]);

  return (
    <div>
      <h1>Factures</h1>
      <div className="card">
        <h3>Nouvelle facture</h3>
        <form action={addInvoice}>
          <input className="input" name="number" placeholder="Numéro (ex: FAC-2026-001)" required />
          <select className="input" name="client_id">
            <option value="">-- Client (optionnel) --</option>
            {(clients || []).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <input className="input" name="description" placeholder="Description" />
          <input className="input" name="total" type="number" step="0.01" placeholder="Montant (FCFA)" required />
          <input className="input" name="due_date" type="date" />
          <button className="btn btn-or" type="submit">Créer la facture</button>
        </form>
      </div>
      <div className="card">
        <table>
          <thead><tr><th>N°</th><th>Client</th><th>Montant</th><th>Statut</th><th></th></tr></thead>
          <tbody>
            {(invoices || []).map(inv => (
              <tr key={inv.id}>
                <td>{inv.number}</td>
                <td>{inv.clients?.name || '—'}</td>
                <td>{Number(inv.total).toLocaleString('fr-FR')} FCFA</td>
                <td><span className={`badge ${STATUS_BADGE[inv.status]}`}>{STATUS_LABEL[inv.status]}</span></td>
                <td style={{ display: 'flex', gap: 8 }}>
                  {inv.status !== 'paid' && (
                    <form action={markInvoicePaid.bind(null, inv.id)}>
                      <button className="btn btn-or" type="submit">Marquer payée</button>
                    </form>
                  )}
                  <form action={deleteInvoice.bind(null, inv.id)}>
                    <button className="btn btn-outline" type="submit">Supprimer</button>
                  </form>
                </td>
              </tr>
            ))}
            {(!invoices || invoices.length === 0) && <tr><td colSpan={5} className="muted">Aucune facture pour l'instant.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
