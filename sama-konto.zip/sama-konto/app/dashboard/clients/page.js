import { createServerSupabase } from '@/lib/supabaseServer';
import { addClient, deleteClient } from '@/lib/actions';

export default async function ClientsPage() {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: clients } = await supabase
    .from('clients').select('*').eq('user_id', user.id).order('created_at', { ascending: false });

  return (
    <div>
      <h1>Clients</h1>
      <div className="card">
        <h3>Ajouter un client</h3>
        <form action={addClient}>
          <input className="input" name="name" placeholder="Nom" required />
          <input className="input" name="email" placeholder="Email" />
          <input className="input" name="phone" placeholder="Téléphone" />
          <input className="input" name="address" placeholder="Adresse" />
          <button className="btn btn-or" type="submit">Ajouter</button>
        </form>
      </div>
      <div className="card">
        <table>
          <thead><tr><th>Nom</th><th>Email</th><th>Téléphone</th><th></th></tr></thead>
          <tbody>
            {(clients || []).map(c => (
              <tr key={c.id}>
                <td>{c.name}</td><td>{c.email}</td><td>{c.phone}</td>
                <td>
                  <form action={deleteClient.bind(null, c.id)}>
                    <button className="btn btn-outline" type="submit">Supprimer</button>
                  </form>
                </td>
              </tr>
            ))}
            {(!clients || clients.length === 0) && <tr><td colSpan={4} className="muted">Aucun client pour l'instant.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
