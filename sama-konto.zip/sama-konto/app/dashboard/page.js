import { createServerSupabase } from '@/lib/supabaseServer';

export default async function DashboardPage() {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();

  const [{ data: invoices }, { data: expenses }, { data: clients }] = await Promise.all([
    supabase.from('invoices').select('total, status').eq('user_id', user.id),
    supabase.from('expenses').select('amount').eq('user_id', user.id),
    supabase.from('clients').select('id').eq('user_id', user.id),
  ]);

  const totalFactures = (invoices || []).reduce((s, i) => s + Number(i.total), 0);
  const totalEncaisse = (invoices || []).filter(i => i.status === 'paid').reduce((s, i) => s + Number(i.total), 0);
  const totalDepenses = (expenses || []).reduce((s, e) => s + Number(e.amount), 0);

  const fmt = (n) => n.toLocaleString('fr-FR') + ' FCFA';

  return (
    <div>
      <h1>Tableau de bord</h1>
      <div className="grid grid-3">
        <div className="card">
          <p className="muted">Total facturé</p>
          <h2 style={{ color: 'var(--or-fonce)' }}>{fmt(totalFactures)}</h2>
        </div>
        <div className="card">
          <p className="muted">Encaissé</p>
          <h2 style={{ color: 'var(--vert)' }}>{fmt(totalEncaisse)}</h2>
        </div>
        <div className="card">
          <p className="muted">Dépenses</p>
          <h2 style={{ color: 'var(--rouge)' }}>{fmt(totalDepenses)}</h2>
        </div>
      </div>
      <div className="card">
        <p className="muted">Clients enregistrés</p>
        <h2>{(clients || []).length}</h2>
      </div>
    </div>
  );
}
