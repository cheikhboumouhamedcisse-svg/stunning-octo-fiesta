import { NextResponse } from 'next/server';
import { stripe, PRICE_MAP } from '@/lib/stripe';
import { createAdminSupabase } from '@/lib/supabaseAdmin';

// Stripe a besoin du corps brut de la requête pour vérifier la signature
export async function POST(request) {
  const body = await request.text();
  const signature = request.headers.get('stripe-signature');

  let event;
  try {
    event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Signature webhook invalide:', err.message);
    return NextResponse.json({ error: `Webhook error: ${err.message}` }, { status: 400 });
  }

  const admin = createAdminSupabase();

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object;
        const subscriptionId = session.subscription;
        const userId = session.metadata?.supabase_user_id;
        if (subscriptionId && userId) {
          const subscription = await stripe.subscriptions.retrieve(subscriptionId);
          await applySubscriptionToProfile(admin, userId, subscription);
        }
        break;
      }
      case 'customer.subscription.updated':
      case 'customer.subscription.created': {
        const subscription = event.data.object;
        const userId = subscription.metadata?.supabase_user_id;
        if (userId) {
          await applySubscriptionToProfile(admin, userId, subscription);
        }
        break;
      }
      case 'customer.subscription.deleted': {
        const subscription = event.data.object;
        const userId = subscription.metadata?.supabase_user_id;
        if (userId) {
          await admin.from('profiles').update({
            subscription_status: 'annulé',
          }).eq('id', userId);
        }
        break;
      }
      default:
        break;
    }
  } catch (err) {
    console.error('Erreur traitement webhook:', err);
    return NextResponse.json({ error: 'Erreur interne' }, { status: 500 });
  }

  return NextResponse.json({ received: true });
}

async function applySubscriptionToProfile(admin, userId, subscription) {
  const update = {
    stripe_subscription_id: subscription.id,
    subscription_status: subscription.status,
  };

  // Chaque ligne de l'abonnement (palier principal + éventuel add-on RH) est croisée avec PRICE_MAP
  for (const item of subscription.items.data) {
    const mapping = PRICE_MAP[item.price.id];
    if (!mapping) continue;
    if (mapping.plan) update.plan = mapping.plan;
    if (mapping.rh_addon) update.rh_addon = true;
  }

  await admin.from('profiles').update(update).eq('id', userId);
}
