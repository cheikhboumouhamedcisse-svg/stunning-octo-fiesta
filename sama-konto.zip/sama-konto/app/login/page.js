'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabaseClient';

export default function LoginPage() {
  const router = useRouter();
  const supabase = createClient();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      setError('Identifiants incorrects. Vérifiez votre email et votre mot de passe.');
      return;
    }
    router.push('/dashboard');
    router.refresh();
  }

  return (
    <div className="container" style={{ maxWidth: 420, paddingTop: 60 }}>
      <h1 className="brand" style={{ color: 'var(--or-fonce)', marginBottom: 4 }}>Sama Konto</h1>
      <div className="card">
        <h2>Connexion</h2>
        {error && <p className="error">{error}</p>}
        <form onSubmit={handleSubmit}>
          <input className="input" type="email" placeholder="Email" required
            value={email} onChange={(e) => setEmail(e.target.value)} />
          <input className="input" type="password" placeholder="Mot de passe" required
            value={password} onChange={(e) => setPassword(e.target.value)} />
          <button className="btn btn-or" type="submit" disabled={loading} style={{ width: '100%' }}>
            {loading ? 'Connexion...' : 'Se connecter'}
          </button>
        </form>
        <p className="muted" style={{ marginTop: 16 }}>
          Pas encore de compte ? <a href="/signup" style={{ color: 'var(--or-fonce)' }}>Créer un compte</a>
        </p>
      </div>
    </div>
  );
}
