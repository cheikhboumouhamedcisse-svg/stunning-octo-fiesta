'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabaseClient';

export default function SignupPage() {
  const router = useRouter();
  const supabase = createClient();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setInfo('');
    setLoading(true);

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { company_name: companyName } },
    });

    setLoading(false);

    if (error) {
      setError(error.message);
      return;
    }

    // Le profil (public.profiles) est créé automatiquement par le trigger SQL on_auth_user_created
    if (data.session) {
      router.push('/dashboard');
      router.refresh();
    } else {
      setInfo('Compte créé. Vérifiez votre boîte mail pour confirmer votre adresse avant de vous connecter.');
    }
  }

  return (
    <div className="container" style={{ maxWidth: 420, paddingTop: 60 }}>
      <h1 className="brand" style={{ color: 'var(--or-fonce)', marginBottom: 4 }}>Sama Konto</h1>
      <div className="card">
        <h2>Créer un compte</h2>
        {error && <p className="error">{error}</p>}
        {info && <p style={{ color: 'var(--vert)' }}>{info}</p>}
        <form onSubmit={handleSubmit}>
          <input className="input" type="text" placeholder="Nom de l'entreprise" required
            value={companyName} onChange={(e) => setCompanyName(e.target.value)} />
          <input className="input" type="email" placeholder="Email" required
            value={email} onChange={(e) => setEmail(e.target.value)} />
          <input className="input" type="password" placeholder="Mot de passe (min. 6 caractères)" required minLength={6}
            value={password} onChange={(e) => setPassword(e.target.value)} />
          <button className="btn btn-or" type="submit" disabled={loading} style={{ width: '100%' }}>
            {loading ? 'Création...' : 'Créer mon compte'}
          </button>
        </form>
        <p className="muted" style={{ marginTop: 16 }}>
          Déjà un compte ? <a href="/login" style={{ color: 'var(--or-fonce)' }}>Se connecter</a>
        </p>
      </div>
    </div>
  );
}
