import './globals.css';

export const metadata = {
  title: 'Sama Konto — Comptabilité & Facturation',
  description: 'La comptabilité et la facturation simplifiées pour les PME sénégalaises.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
