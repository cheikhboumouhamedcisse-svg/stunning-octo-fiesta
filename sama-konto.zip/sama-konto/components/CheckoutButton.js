'use client';
import { useState } from 'react';

export default function CheckoutButton({ priceId, label }) {
  const [loading, setLoading] = useState(false);

  async function handleClick() {
    if (!priceId) {
      alert("Ce prix Stripe n'est pas configuré (variable d'environnement manquante).");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/stripe/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ priceId }),
      });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        alert(data.error || 'Impossible de démarrer le paiement.');
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <button onClick={handleClick} disabled={loading} className="btn btn-or" style={{ width: '100%' }}>
      {loading ? 'Redirection...' : label}
    </button>
  );
}
