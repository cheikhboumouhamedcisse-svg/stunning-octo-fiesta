'use client';
import { useState } from 'react';

export default function ManageSubscriptionButton() {
  const [loading, setLoading] = useState(false);

  async function openPortal() {
    setLoading(true);
    try {
      const res = await fetch('/api/stripe/portal', { method: 'POST' });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        alert(data.error || "Impossible d'ouvrir le portail d'abonnement.");
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <button onClick={openPortal} disabled={loading} className="btn btn-outline"
      style={{ color: 'var(--parchemin)', borderColor: 'var(--parchemin)' }}>
      {loading ? '...' : 'Gérer mon abonnement'}
    </button>
  );
}
