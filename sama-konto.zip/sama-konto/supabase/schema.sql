-- ============================================================
-- SAMA KONTO — Schéma Supabase (Postgres)
-- À exécuter dans Supabase > SQL Editor
-- ============================================================

create extension if not exists "pgcrypto";

-- Profil utilisateur (1 ligne par compte, liée à auth.users)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  company_name text,
  phone text,
  plan text not null default 'simple' check (plan in ('simple','pro','promax')),
  rh_addon boolean not null default false,
  stripe_customer_id text,
  stripe_subscription_id text,
  subscription_status text default 'inactive',
  created_at timestamptz not null default now()
);

create table if not exists public.clients (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  email text,
  phone text,
  address text,
  created_at timestamptz not null default now()
);

create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  client_id uuid references public.clients(id) on delete set null,
  number text not null,
  issue_date date not null default current_date,
  due_date date,
  items jsonb not null default '[]',
  total numeric(14,2) not null default 0,
  status text not null default 'draft' check (status in ('draft','sent','paid','overdue')),
  created_at timestamptz not null default now()
);

create table if not exists public.quotes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  client_id uuid references public.clients(id) on delete set null,
  number text not null,
  issue_date date not null default current_date,
  items jsonb not null default '[]',
  total numeric(14,2) not null default 0,
  status text not null default 'draft' check (status in ('draft','sent','accepted','refused')),
  created_at timestamptz not null default now()
);

create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  date date not null default current_date,
  category text not null,
  description text,
  amount numeric(14,2) not null default 0,
  created_at timestamptz not null default now()
);

-- Module RH add-on
create table if not exists public.employees (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  role text,
  salary numeric(14,2),
  hired_at date,
  created_at timestamptz not null default now()
);

create table if not exists public.leaves (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  employee_id uuid not null references public.employees(id) on delete cascade,
  start_date date not null,
  end_date date not null,
  type text default 'congé payé',
  status text not null default 'en attente' check (status in ('en attente','approuvé','refusé')),
  created_at timestamptz not null default now()
);

create table if not exists public.attendance (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  employee_id uuid not null references public.employees(id) on delete cascade,
  date date not null default current_date,
  status text not null default 'présent' check (status in ('présent','absent')),
  created_at timestamptz not null default now(),
  unique (employee_id, date)
);

-- ============================================================
-- Row Level Security : chaque utilisateur ne voit que ses données
-- ============================================================
alter table public.profiles enable row level security;
alter table public.clients enable row level security;
alter table public.invoices enable row level security;
alter table public.quotes enable row level security;
alter table public.expenses enable row level security;
alter table public.employees enable row level security;
alter table public.leaves enable row level security;
alter table public.attendance enable row level security;

create policy "profile: self select" on public.profiles for select using (auth.uid() = id);
create policy "profile: self update" on public.profiles for update using (auth.uid() = id);

create policy "clients: owner all" on public.clients for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "invoices: owner all" on public.invoices for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "quotes: owner all" on public.quotes for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "expenses: owner all" on public.expenses for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "employees: owner all" on public.employees for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "leaves: owner all" on public.leaves for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "attendance: owner all" on public.attendance for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Création automatique du profil à l'inscription
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, plan, rh_addon)
  values (new.id, 'simple', false)
  on conflict (id) do nothing;
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
