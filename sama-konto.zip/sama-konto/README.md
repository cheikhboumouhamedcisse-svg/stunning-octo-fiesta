# Sama Konto — Backend Supabase + Stripe

Application Next.js pour Sama Konto (comptabilité/facturation) avec :
- **Authentification et base de données** : Supabase (email/mot de passe + Postgres avec RLS)
- **Paiements et abonnements** : Stripe Checkout + portail client + webhook

Ceci remplace la version "démo" qui stockait tout en `localStorage` dans le navigateur : ici, les données sont dans une vraie base de données et les abonnements sont gérés par Stripe.

## 1. Créer le projet Supabase

1. Va sur [supabase.com](https://supabase.com) → New Project (choisis une région proche, ex. Europe).
2. Dans **SQL Editor**, colle le contenu de `supabase/schema.sql` et exécute-le. Cela crée toutes les tables, la sécurité au niveau des lignes (RLS) et le trigger qui crée automatiquement un profil à l'inscription.
3. Dans **Project Settings > API**, récupère :
   - `Project URL` → `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public` key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role` key (⚠️ secrète) → `SUPABASE_SERVICE_ROLE_KEY`
4. Dans **Authentication > Providers**, vérifie qu'Email est activé. Tu peux désactiver "Confirm email" pendant les tests pour te connecter immédiatement après inscription.

## 2. Créer le compte Stripe et les prix

⚠️ **Important pour le Sénégal** : Stripe ne permet pas encore de créer un compte "payout" basé au Sénégal, et ne facture pas nativement en FCFA (XOF) pour la plupart des comptes. En pratique, deux options :
- Créer le compte Stripe dans un pays supporté (ex. si tu as une structure ou un associé basé en France/UE, aux USA, etc.) et facturer en EUR ou USD (avec un montant équivalent aux prix FCFA affichés) ;
- Ou utiliser un fournisseur de paiement local (Wave, Orange Money, PayDunya, CinetPay...) à la place de Stripe pour l'encaissement réel, tout en gardant cette architecture Supabase pour la base de données.

Le code ci-dessous fonctionne techniquement avec n'importe quel compte Stripe ; à toi de vérifier l'éligibilité de ton compte avant de passer en production.

1. Va sur [dashboard.stripe.com](https://dashboard.stripe.com) → crée un compte (ou utilise le mode Test pour commencer).
2. Dans **Product catalog**, crée 3 produits avec un prix récurrent mensuel :
   - Sama Konto Simple
   - Sama Konto Pro
   - Sama Konto Pro Max
   - Puis 2 prix supplémentaires pour l'add-on RH (Simple et Pro).
3. Copie chaque `price_id` dans `.env` (`STRIPE_PRICE_SIMPLE`, `STRIPE_PRICE_PRO`, `STRIPE_PRICE_PROMAX`, `STRIPE_PRICE_RH_SIMPLE`, `STRIPE_PRICE_RH_PRO`).
4. Dans **Developers > API keys**, récupère `STRIPE_SECRET_KEY` et `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`.
5. Le `STRIPE_WEBHOOK_SECRET` sera créé à l'étape 4 (après déploiement).

## 3. Configuration locale

```bash
cp .env.example .env
# remplis toutes les valeurs
npm install
npm run dev
```

L'app tourne sur http://localhost:3000.

Pour tester le webhook Stripe en local, utilise la CLI Stripe :
```bash
stripe listen --forward-to localhost:3000/api/stripe/webhook
```
Elle t'affiche un `whsec_...` à mettre dans `STRIPE_WEBHOOK_SECRET` pour les tests locaux.

## 4. Déploiement (Vercel recommandé)

1. Pousse ce projet sur GitHub.
2. Va sur [vercel.com](https://vercel.com) → New Project → importe le repo.
3. Dans **Settings > Environment Variables**, ajoute toutes les variables de `.env.example` avec tes vraies valeurs.
4. Déploie.
5. Une fois l'URL de production connue (ex. `https://sama-konto.vercel.app`) :
   - Mets à jour `NEXT_PUBLIC_SITE_URL` dans les variables d'environnement Vercel.
   - Dans Stripe Dashboard → **Developers > Webhooks** → Add endpoint → URL : `https://ton-domaine/api/stripe/webhook` → sélectionne les événements `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.created`, `customer.subscription.deleted`.
   - Copie le `Signing secret` (`whsec_...`) dans `STRIPE_WEBHOOK_SECRET` sur Vercel, puis redéploie.

## 5. Ce que fait chaque partie

- **Inscription/connexion** (`/signup`, `/login`) : Supabase Auth. Un profil (`public.profiles`) est créé automatiquement à l'inscription via un trigger SQL.
- **Tableau de bord** (`/dashboard/*`) : factures, devis, clients, dépenses — toutes les données sont lues/écrites dans Supabase via des Server Actions Next.js (`lib/actions.js`), protégées par la RLS (chaque utilisateur ne voit que ses propres données).
- **Module RH** (`/dashboard/rh`) : verrouillé tant que `profiles.rh_addon` est `false`. Ce champ est automatiquement mis à jour par le webhook Stripe quand l'utilisateur paie l'add-on RH ou passe en Pro Max.
- **Abonnement** (`/pricing`) : boutons Stripe Checkout par palier. Le webhook Stripe (`/api/stripe/webhook`) met à jour `profiles.plan` et `profiles.rh_addon` dans Supabase après paiement.
- **Gestion d'abonnement** : bouton "Gérer mon abonnement" dans le tableau de bord → ouvre le portail client Stripe (annulation, changement de carte, etc.).

## 6. Prochaines étapes possibles

- Génération de vraies factures PDF téléchargeables.
- Gestion multi-articles par facture/devis (actuellement une ligne unique par simplicité).
- Emails transactionnels (facture envoyée, relance impayé) via Resend ou un SMTP.
- Passage à un fournisseur de paiement mobile local si Stripe n'est pas utilisable pour l'encaissement final.
